#!/bin/bash


cd $EXEDIR/gamil_demo
rm -f *.o
rm -f gamil

