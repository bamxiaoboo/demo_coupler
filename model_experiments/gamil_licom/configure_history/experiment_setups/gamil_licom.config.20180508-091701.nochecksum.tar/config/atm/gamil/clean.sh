#!/bin/bash


cd $EXEDIR/gamil_demo

rm -f *.o *.mod
rm -f gamil

