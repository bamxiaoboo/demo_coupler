#!/bin/bash


cd $EXEDIR/licom_demo

rm -f *.o *.mod
rm -f gamil

